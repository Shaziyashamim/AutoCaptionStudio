package com.autocaptionstudio

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private val pickVideoCode = 41
    private val audioPermissionCode = 42

    private lateinit var videoView: android.widget.VideoView
    private lateinit var captionPreview: TextView
    private lateinit var captionInput: EditText
    private lateinit var fontSpinner: Spinner
    private lateinit var languageSpinner: Spinner
    private lateinit var status: TextView
    private lateinit var listenButton: Button
    private var speechRecognizer: SpeechRecognizer? = null

    private val fontNames = listOf(
        "Sans Serif", "Sans Serif Bold", "Serif", "Serif Bold",
        "Monospace", "Cursive", "Casual", "Serif Italic"
    )
    private val languageModes = listOf(
        "Hinglish (Roman)", "Hindi", "English", "Urdu"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(17, 17, 24)
        window.navigationBarColor = Color.rgb(17, 17, 24)
        buildScreen()
    }

    private fun buildScreen() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(24))
            setBackgroundColor(Color.rgb(17, 17, 24))
        }

        page.addView(TextView(this).apply {
            text = "AUTO CAPTION STUDIO"
            textSize = 20f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        })
        page.addView(TextView(this).apply {
            text = "Natural Hinglish • Hindi • English • Urdu"
            textSize = 13f
            setTextColor(Color.LTGRAY)
            setPadding(0, dp(5), 0, dp(16))
        })

        val choose = makeButton("＋  Choose video")
        choose.setOnClickListener { openVideoPicker() }
        page.addView(choose)

        val previewFrame = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        videoView = android.widget.VideoView(this)
        previewFrame.addView(videoView, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, dp(220)
        ))
        captionPreview = TextView(this).apply {
            text = "Your caption will appear here"
            textSize = 22f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setShadowLayer(5f, 2f, 2f, Color.BLACK)
            setPadding(dp(12), dp(8), dp(12), dp(8))
        }
        previewFrame.addView(captionPreview, FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        ))
        page.addView(previewFrame, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(220)
        ).apply { topMargin = dp(14) })

        page.addView(makeLabel("Subtitle language"))
        languageSpinner = Spinner(this)
        languageSpinner.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, languageModes
        )
        page.addView(languageSpinner)

        listenButton = makeButton("🎙  Generate subtitles with speech")
        listenButton.setOnClickListener { startSpeechCapture() }
        page.addView(listenButton)

        page.addView(makeLabel("Edit your caption"))
        captionInput = EditText(this).apply {
            hint = "Aaj market band hai..."
            setHintTextColor(Color.GRAY)
            setTextColor(Color.WHITE)
            textSize = 16f
            minLines = 2
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setBackgroundColor(Color.rgb(38, 38, 50))
        }
        page.addView(captionInput)

        page.addView(makeLabel("Typography style (starter set)"))
        fontSpinner = Spinner(this)
        fontSpinner.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, fontNames
        )
        page.addView(fontSpinner)

        val apply = makeButton("Apply caption style")
        apply.setOnClickListener { applyCaptionStyle() }
        page.addView(apply)

        status = TextView(this).apply {
            text = "Free speech recognition uses the speech service available on your Android phone."
            textSize = 12f
            setTextColor(Color.LTGRAY)
            setPadding(0, dp(14), 0, dp(4))
        }
        page.addView(status)

        val note = TextView(this).apply {
            text = "Note: Hinglish Roman output is best-effort. Recognition quality and offline support depend on your phone's installed speech service and language packs."
            textSize = 11f
            setTextColor(Color.rgb(180, 180, 195))
            setPadding(0, dp(8), 0, 0)
        }
        page.addView(note)

        setContentView(android.widget.ScrollView(this).apply {
            addView(page)
            isFillViewport = true
        })
    }

    private fun startSpeechCapture() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.text = "No speech recognition service found. Install/enable a speech service on your phone."
            return
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                this, arrayOf(Manifest.permission.RECORD_AUDIO), audioPermissionCode
            )
            return
        }

        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { status.text = "Listening… speak clearly." }
            override fun onBeginningOfSpeech() { status.text = "Hearing your voice…" }
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { status.text = "Processing speech…" }
            override fun onError(error: Int) {
                status.text = "Speech recognition error ($error). Try again or check your speech service/language pack."
                listenButton.isEnabled = true
            }
            override fun onResults(results: Bundle?) {
                val lines = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val text = lines?.firstOrNull().orEmpty()
                if (text.isNotBlank()) {
                    captionInput.setText(text)
                    captionPreview.text = text
                    status.text = "Transcript added. You can edit it before applying."
                } else status.text = "No speech detected. Please try again."
                listenButton.isEnabled = true
            }
            override fun onPartialResults(partialResults: Bundle?) {
                val partial = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                if (!partial.isNullOrBlank()) status.text = "Recognizing: $partial"
            }
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })

        val localeTag = when (languageSpinner.selectedItemPosition) {
            1 -> "hi-IN"
            2 -> "en-IN"
            3 -> "ur-PK"
            else -> "en-IN" // best-effort Roman Hinglish
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, localeTag)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, localeTag)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
        }
        listenButton.isEnabled = false
        speechRecognizer?.startListening(intent)
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == audioPermissionCode) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                startSpeechCapture()
            } else status.text = "Microphone permission is needed to generate subtitles."
        }
    }

    private fun applyCaptionStyle() {
        val value = captionInput.text.toString().ifBlank { "Your caption will appear here" }
        captionPreview.text = value
        captionPreview.typeface = when (fontSpinner.selectedItemPosition) {
            0 -> Typeface.create("sans-serif", Typeface.NORMAL)
            1 -> Typeface.create("sans-serif", Typeface.BOLD)
            2 -> Typeface.create("serif", Typeface.NORMAL)
            3 -> Typeface.create("serif", Typeface.BOLD)
            4 -> Typeface.create("monospace", Typeface.NORMAL)
            5 -> Typeface.create("cursive", Typeface.NORMAL)
            6 -> Typeface.create("casual", Typeface.NORMAL)
            else -> Typeface.create("serif", Typeface.ITALIC)
        }
        status.text = "Caption preview updated."
    }

    private fun openVideoPicker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "video/*"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(intent, pickVideoCode)
    }

    @Deprecated("Deprecated by Android API; retained for broad device compatibility in this starter.")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickVideoCode && resultCode == Activity.RESULT_OK) {
            val uri: Uri? = data?.data
            if (uri != null) {
                try {
                    contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } catch (_: Exception) { }
                videoView.setVideoURI(uri)
                videoView.setOnPreparedListener { player ->
                    player.isLooping = true
                    videoView.start()
                }
                status.text = "Video loaded. Generate or type a caption."
            }
        }
    }

    private fun makeButton(label: String): Button = Button(this).apply {
        text = label
        isAllCaps = false
        setTextColor(Color.WHITE)
        setBackgroundColor(Color.rgb(124, 58, 237))
        layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(12) }
    }

    private fun makeLabel(label: String) = TextView(this).apply {
        text = label
        textSize = 14f
        setTextColor(Color.WHITE)
        typeface = Typeface.DEFAULT_BOLD
        setPadding(0, dp(16), 0, dp(6))
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        speechRecognizer?.destroy()
        speechRecognizer = null
        super.onDestroy()
    }
}
