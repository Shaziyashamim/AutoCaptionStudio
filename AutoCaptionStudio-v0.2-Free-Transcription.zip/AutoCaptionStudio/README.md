# Auto Caption Studio — Android starter v0.2

## Added in v0.2
- Native Android Kotlin project
- Gallery video picker and video preview
- Manual caption editing and preview
- Starter typeface choices
- Free Android SpeechRecognizer integration
- Language modes: Hinglish (best-effort Roman), Hindi, English, Urdu
- GitHub Actions cloud APK build

## Free transcription details
This build uses the speech recognition service available on the Android device. There is no paid API key or subscription in the project. Depending on the phone, its installed speech service may process speech online or use downloaded offline language packs. The app cannot guarantee free offline recognition on every device.

Hinglish mode requests `en-IN` recognition as a best-effort way to get Roman-script mixed speech. Mixed Hindi-English recognition and spellings such as WhatsApp-style Roman Hinglish are not guaranteed; users can edit the transcript.

## Not yet implemented
- 100+ real bundled font files / custom font manager
- Per-word font mix-and-match and timeline
- Word-level timestamps and subtitle synchronization
- Burned-in MP4 export and gallery saving
- Production testing across Android devices

## Build APK using GitHub
1. Create a repository named `AutoCaptionStudio`.
2. Upload the contents of this folder to the repository root.
3. Open Actions and select `Build Android APK`.
4. Run workflow or push to `main`.
5. Download the `AutoCaptionStudio-v0.2-debug` artifact from the workflow run.
6. Extract the artifact ZIP and install `app-debug.apk`.

This is a development starter, not a finished production app.
